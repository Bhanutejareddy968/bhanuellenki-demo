import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Github, 
  Linkedin, 
  Mail, 
  ExternalLink, 
  Code, 
  Database, 
  Smartphone,
  Award,
  BookOpen,
  Send
} from "lucide-react";
import heroBackground from "@/assets/hero-background.jpg";
import profilePhoto from "@/assets/profile-photo.jpg";

const Portfolio = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });

  const skills = [
    { name: "HTML5", icon: Code, category: "Frontend" },
    { name: "CSS3", icon: Code, category: "Frontend" },
    { name: "JavaScript", icon: Code, category: "Frontend" },
    { name: "React", icon: Code, category: "Frameworks" },
    { name: "Git", icon: Github, category: "Tools" },
    { name: "Responsive Design", icon: Smartphone, category: "Frontend" }
  ];

  const projects = [
    {
      title: "Modern E-Commerce Platform",
      description: "A responsive e-commerce site with dynamic product catalogs and smooth user experience.",
      tags: ["React", "CSS3", "JavaScript"],
      liveDemo: "#",
      github: "#",
      image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&h=400&fit=crop"
    },
    {
      title: "Interactive Dashboard",
      description: "Data visualization dashboard with real-time updates and intuitive interface.",
      tags: ["JavaScript", "HTML5", "CSS3"],
      liveDemo: "#",
      github: "#",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop"
    },
    {
      title: "Portfolio Website",
      description: "Fully responsive portfolio showcasing modern web development techniques.",
      tags: ["React", "CSS3", "Responsive"],
      liveDemo: "#",
      github: "#",
      image: "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=600&h=400&fit=crop"
    }
  ];

  const achievements = [
    { title: "HTML5 Certification", issuer: "Web Standards Academy", year: "2024" },
    { title: "CSS3 Advanced Techniques", issuer: "Frontend Masters", year: "2024" },
    { title: "JavaScript Fundamentals", issuer: "Tech Institute", year: "2024" }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    // Handle form submission
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section 
        className="relative min-h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroBackground})` }}
      >
        <div className="absolute inset-0 bg-gradient-hero opacity-80"></div>
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <div className="animate-float">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 glow-text">
              Hi, I'm <span className="gradient-text">Bhanu Teja Reddy</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-muted-foreground">
              A Frontend Developer Building Modern Web Solutions
            </p>
            <p className="text-lg mb-12 text-foreground/80 max-w-2xl mx-auto">
              Passionate about creating scalable, modern, and interactive web applications 
              with cutting-edge technologies and future-focused design.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-glow-pulse">
            <Button size="lg" className="cyber-border hover-glow">
              <Code className="mr-2 h-5 w-5" />
              View My Work
            </Button>
            <Button variant="secondary" size="lg" className="cyber-border hover-glow">
              <Mail className="mr-2 h-5 w-5" />
              Contact Me
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16 gradient-text">About Me</h2>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <Card className="p-8 cyber-border hover-glow">
                <div className="w-48 h-48 mx-auto mb-6 rounded-full bg-gradient-primary p-1">
                  <img 
                    src={profilePhoto} 
                    alt="Bhanu Teja Reddy - Frontend Developer"
                    className="w-full h-full rounded-full object-cover"
                  />
                </div>
              </Card>
            </div>
            <div className="space-y-6">
              <Card className="p-8 cyber-border hover-glow">
                <h3 className="text-2xl font-bold mb-4 text-primary">Frontend Developer</h3>
                <p className="text-muted-foreground mb-4">
                  I'm a passionate frontend developer with expertise in modern web technologies. 
                  I specialize in creating responsive, user-friendly interfaces that deliver 
                  exceptional user experiences.
                </p>
                <p className="text-muted-foreground mb-4">
                  My journey in web development is driven by a constant desire to learn and 
                  implement the latest technologies to build scalable, modern applications.
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary" className="glow-purple">HTML5</Badge>
                  <Badge variant="secondary" className="glow-purple">CSS3</Badge>
                  <Badge variant="secondary" className="glow-purple">JavaScript</Badge>
                  <Badge variant="secondary" className="glow-purple">React</Badge>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 px-4 bg-dark-surface">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16 gradient-text">Skills & Technologies</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {skills.map((skill, index) => (
              <Card key={index} className="p-6 text-center cyber-border hover-glow group">
                <skill.icon className="h-12 w-12 mx-auto mb-4 text-primary group-hover:text-neon-cyan transition-colors" />
                <h3 className="font-semibold mb-2">{skill.name}</h3>
                <Badge variant="outline" className="text-xs">{skill.category}</Badge>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16 gradient-text">Featured Projects</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <Card key={index} className="overflow-hidden cyber-border hover-glow group">
                <div className="aspect-video bg-muted bg-cover bg-center" 
                     style={{ backgroundImage: `url(${project.image})` }}>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-3 text-primary">{project.title}</h3>
                  <p className="text-muted-foreground mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tags.map((tag, tagIndex) => (
                      <Badge key={tagIndex} variant="secondary" className="glow-green">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-3">
                    <Button size="sm" variant="outline" className="cyber-border hover-glow">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Live Demo
                    </Button>
                    <Button size="sm" variant="outline" className="cyber-border hover-glow">
                      <Github className="h-4 w-4 mr-2" />
                      Code
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Achievements Section */}
      <section id="achievements" className="py-20 px-4 bg-dark-surface">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16 gradient-text">Achievements & Certifications</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {achievements.map((achievement, index) => (
              <Card key={index} className="p-6 cyber-border hover-glow">
                <Award className="h-12 w-12 text-primary mb-4 mx-auto" />
                <h3 className="text-xl font-bold text-center mb-2">{achievement.title}</h3>
                <p className="text-muted-foreground text-center mb-2">{achievement.issuer}</p>
                <Badge variant="secondary" className="mx-auto block w-fit glow-purple">{achievement.year}</Badge>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16 gradient-text">Let's Build Something Great Together!</h2>
          <div className="grid md:grid-cols-2 gap-12">
            <Card className="p-8 cyber-border hover-glow">
              <h3 className="text-2xl font-bold mb-6 text-primary">Get In Touch</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Mail className="h-5 w-5 text-neon-cyan" />
                  <span>bhanu.tejareddy@email.com</span>
                </div>
                <div className="flex items-center gap-3">
                  <Linkedin className="h-5 w-5 text-neon-cyan" />
                  <span>linkedin.com/in/bhanutejareddy</span>
                </div>
                <div className="flex items-center gap-3">
                  <Github className="h-5 w-5 text-neon-cyan" />
                  <span>github.com/bhanutejareddy</span>
                </div>
              </div>
            </Card>

            <Card className="p-8 cyber-border hover-glow">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <Input
                    placeholder="Your Name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="cyber-border"
                  />
                </div>
                <div>
                  <Input
                    type="email"
                    placeholder="Your Email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className="cyber-border"
                  />
                </div>
                <div>
                  <Textarea
                    placeholder="Your Message"
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    className="cyber-border min-h-[120px]"
                  />
                </div>
                <Button type="submit" className="w-full cyber-border hover-glow">
                  <Send className="h-4 w-4 mr-2" />
                  Send Message
                </Button>
              </form>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 bg-darker-surface border-t border-border">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <p className="text-muted-foreground">
                © 2024 Bhanu Teja Reddy. Built with ❤️ and modern web technologies.
              </p>
            </div>
            <div className="flex gap-4">
              <Button variant="ghost" size="sm" className="hover-glow">
                <Github className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="sm" className="hover-glow">
                <Linkedin className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="sm" className="hover-glow">
                <Mail className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Portfolio;